# render

A simple rasterising renderer for the go-text project.
Draw your text into a `draw.Image` provided by the developer for caching / overlay opportunities.
