package harfbuzz

import "embed"

// Files provides font samples used for the harfbuzz test suite.
//
//go:embed *
var Files embed.FS
