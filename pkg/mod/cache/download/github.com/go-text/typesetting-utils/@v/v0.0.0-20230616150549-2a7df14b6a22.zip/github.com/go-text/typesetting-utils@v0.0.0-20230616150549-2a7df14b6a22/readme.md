# Developpement resources for go-text/typesetting

This module provides resources used when developping [go-text/typesetting](https://github.com/go-text/typesetting), such as :
 - font files 
 - code generators 

