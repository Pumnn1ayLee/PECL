# di

di is a library that converts bi-directional text into uni-directional text
