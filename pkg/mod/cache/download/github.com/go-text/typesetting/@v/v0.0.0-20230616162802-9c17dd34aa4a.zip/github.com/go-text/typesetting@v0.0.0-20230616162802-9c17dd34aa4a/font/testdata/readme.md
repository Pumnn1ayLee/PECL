# Font samples for testing

This directory includes font files used for testing.

### Licenses

- Roboto-Regular.ttf: APACHE (https://fonts.google.com/specimen/Roboto)
- Amiri-Regular.ttf: OFL (https://fonts.google.com/specimen/Amiri)
