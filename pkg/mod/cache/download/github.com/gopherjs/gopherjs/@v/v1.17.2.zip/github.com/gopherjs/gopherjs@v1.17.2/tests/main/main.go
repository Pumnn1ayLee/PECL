package main

var mainDidRun = false

func main() {
	mainDidRun = true
}
