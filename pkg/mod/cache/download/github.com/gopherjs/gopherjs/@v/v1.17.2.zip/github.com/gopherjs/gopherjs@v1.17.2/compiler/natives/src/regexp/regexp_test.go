//go:build js
// +build js

package regexp

import (
	"testing"
)

func TestOnePassCutoff(t *testing.T) {
	t.Skip() // "Maximum call stack size exceeded" on V8
}
