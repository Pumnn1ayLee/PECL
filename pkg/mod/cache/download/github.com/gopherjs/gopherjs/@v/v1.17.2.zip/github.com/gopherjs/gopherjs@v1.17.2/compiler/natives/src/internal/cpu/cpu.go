//go:build js
// +build js

package cpu

const (
	CacheLineSize    = 0
	CacheLinePadSize = 0
)

func doinit() {}
